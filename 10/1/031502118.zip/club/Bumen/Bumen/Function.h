﻿#pragma once
#include<iostream>
#include<string>
using namespace std;
class Function {
public:
	void input();//数据读入
	//void PrintData();//数据输出
	void GetRank();//权重计算
	void sort();//权重排序
	void print();//结果输出
};